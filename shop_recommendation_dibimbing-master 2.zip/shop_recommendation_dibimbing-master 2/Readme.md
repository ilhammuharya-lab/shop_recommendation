# Shop Recommendation
Repository ini adalah shop recommendation yang digunakan untuk Bootcamp pada dibimbing.  
# Prerequisite
Install library berikut:
```bash
haystack-ai==2.15.2
mongodb-atlas-haystack==3.3.0
sentence-transformers==5.0.0
pandas==2.3.1
pymongo==4.13.2
streamlit==1.47.1
python-dotenv==1.1.1
ipykernel==6.29.5
```