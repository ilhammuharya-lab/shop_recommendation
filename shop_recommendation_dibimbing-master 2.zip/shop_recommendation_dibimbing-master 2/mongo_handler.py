from pymongo import MongoClient
import os
from dotenv import load_dotenv

load_dotenv()

class MongoHandler:
    def __init__(self):
        self.client = MongoClient(os.getenv("MONGODB_URI"))
        self.db = self.client["shop_recommendation"]
        self.conversations = self.db["conversations"]
    
    def log_conversation(self, user_id: str, question: str, response: str, tool: str):
        self.conversations.insert_one({
            "user_id": user_id,
            "question": question,
            "response": response,
            "tool": tool,
            "timestamp": datetime.now()
        })
    
    def close(self):
        self.client.close()