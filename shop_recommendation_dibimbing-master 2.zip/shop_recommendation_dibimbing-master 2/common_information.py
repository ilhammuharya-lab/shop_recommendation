import json
from typing import Dict, List

class CommonInformationTool:
    def __init__(self):
        self.knowledge_base = self._load_knowledge_base()
    
    def _load_knowledge_base(self) -> Dict[str, List[str]]:
        with open('common_questions.json', 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def get_response(self, question: str) -> str:
        question_lower = question.lower()
        
        # Cek pertanyaan spesifik
        for category in self.knowledge_base['categories']:
            for qa in category['qa_pairs']:
                if question_lower in qa['question'].lower():
                    return qa['answer']
        
        # Cek berdasarkan keyword
        for category in self.knowledge_base['categories']:
            for qa in category['qa_pairs']:
                if any(keyword in question_lower 
                      for keyword in qa['keywords']):
                    return qa['answer']
        
        return "Maaf, saya tidak mengerti pertanyaan Anda. Silakan tanyakan hal lain tentang toko kami."